# R8 shrinks code and resources; the defaults are enough for this app
-dontwarn org.jetbrains.annotations.**
