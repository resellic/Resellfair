package com.resellfair.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/* ------------------------------ TICKETS ------------------------------ */
@Composable
fun TicketsScreen(nav: Nav, start: Int) {
    var f by remember { mutableIntStateOf(start) }
    val keys = listOf("all", "open", "answered", "closed")
    val (r, retry) = useApi("tk$f") { Api.call("tickets", mapOf("f" to keys[f])) }
    Column(Modifier.fillMaxSize()) {
        FilterRow(listOf("All", "Open", "Answered", "Closed"), f) { f = it }
        Body(r, retry) { j ->
            val rows = j.optJSONArray("data")?.list() ?: emptyList()
            if (rows.isEmpty()) Empty("No tickets") else Page {
                rows.forEach { t -> RowCard(t.optString("subject"), t.optString("ticket_no") + " · " + t.optString("email"), "", t.optString("status")) { nav(Route("ticket", t.optString("id"))) } }
            }
        }
    }
}

@Composable
fun TicketThread(id: String) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    val (r, retry) = useApi("ticket$id") { Api.call("ticket", mapOf("id" to id)) }
    var msg by remember { mutableStateOf("") }
    Body(r, retry) { j ->
        val t = j.getJSONObject("ticket")
        val closed = t.optString("status") == "closed"
        Page {
            RowCard(t.optString("subject"), t.optString("email"), "", t.optString("status"))
            j.optJSONArray("replies")?.list()?.forEach { m ->
                val staff = m.optInt("is_staff") == 1
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalAlignment = if (staff) Alignment.End else Alignment.Start) {
                    Column(Modifier.fillMaxWidth(0.88f).background(if (staff) Blue else Soft, androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).padding(12.dp)) {
                        Text(m.optString("message"), color = if (staff) Color.White else Ink, fontSize = 14.sp)
                        Text(m.optString("created_at"), color = if (staff) Color(0xFFBFD3FF) else Mute, fontSize = 10.sp)
                    }
                }
            }
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("Reply", msg, { msg = it }, lines = 3)
                Btn("Send reply", Blue, Modifier.fillMaxWidth()) {
                    if (msg.isNotBlank()) sc.launch { if (doAct(ctx) { Api.call("ticket_reply", body = mapOf("id" to id, "message" to msg)) }) { msg = ""; retry() } }
                }
                if (!closed) GhostBtn("Close ticket", Modifier.fillMaxWidth()) {
                    sc.launch { if (doAct(ctx) { Api.call("ticket_reply", body = mapOf("id" to id, "close" to "1")) }) retry() }
                }
            }
        }
    }
}

/* ------------------------------ NOTICES ------------------------------ */
@Composable
fun NoticesScreen() {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    val (r, retry) = useApi("notifs") { Api.call("notifs") }
    Body(r, retry) { j ->
        Session.unread = j.optInt("unread")
        val rows = j.optJSONArray("data")?.list() ?: emptyList()
        Page {
            if (rows.isNotEmpty()) Text("Mark all as read", color = Blue, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(16.dp).clickable { sc.launch { if (doAct(ctx) { Api.call("notif_read", body = mapOf()) }) retry() } })
            if (rows.isEmpty()) Empty("No notices")
            rows.forEach { n ->
                RowCard(n.optString("title"), n.optString("message") + "\n" + n.optString("created_at"), "", if (n.optInt("is_read") == 0) "new" else "") {
                    sc.launch { if (doAct(ctx) { Api.call("notif_read", body = mapOf("id" to n.optString("id"))) }) retry() }
                }
            }
        }
    }
}

/* ------------------------------ MORE ------------------------------ */
@Composable
fun MoreScreen(nav: Nav, onLock: () -> Unit, onLogout: () -> Unit) {
    val groups = listOf(
        "Domains" to listOf("All domains" to Route("page", "domains.php"), "Extensions and prices" to Route("page", "tlds.php"), "Registrar" to Route("page", "registrars.php")),
        "Money" to listOf("Invoices" to Route("page", "invoices.php"), "Payment methods" to Route("page", "gateways.php"), "Referrals" to Route("page", "referrals.php")),
        "Support" to listOf("Tickets" to Route("tickets", "0"), "Notices" to Route("notices")),
        "System" to listOf("Team" to Route("page", "team.php"), "Backup" to Route("page", "backup.php"), "Settings" to Route("page", "settings.php"))
    )
    Page {
        groups.forEach { (g, items) ->
            Text(g.uppercase(), color = Mute, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp))
            Column(Modifier.padding(horizontal = 12.dp).fillMaxWidth().background(Soft, androidx.compose.foundation.shape.RoundedCornerShape(14.dp))) {
                items.forEachIndexed { i, (label, route) ->
                    Row(Modifier.fillMaxWidth().clickable { nav(route) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text("›", color = Mute, fontSize = 20.sp)
                    }
                    if (i < items.size - 1) Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
                }
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GhostBtn("Lock app", Modifier.fillMaxWidth()) { onLock() }
            Btn("Log out", Red, Modifier.fillMaxWidth()) { onLogout() }
        }
    }
}

/* ------------------------------ GENERIC ADMIN PAGE ------------------------------ */
@Composable
fun PageScreen(p: String, q: String, nav: Nav) {
    val (r, retry) = useApi("page$p$q") { Api.call("page", mapOf("p" to p, "q" to q)) }
    Body(r, retry) { j ->
        Page { (j.optJSONArray("blocks")?.list() ?: emptyList()).forEach { Block(it, p, q, nav, retry) } }
    }
}

fun linkNav(t: JSONObject?, curP: String, nav: Nav) {
    if (t == null) return
    val p = t.optString("p").ifEmpty { curP }
    nav(Route("page", p, t.optString("q")))
}

@Composable
fun Block(b: JSONObject, curP: String, curQ: String, nav: Nav, reload: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    when (b.optString("type")) {
        "heading" -> Text(b.optString("text"), fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp))
        "note" -> Text(b.optString("text"), color = Mute, fontSize = 13.sp, modifier = Modifier.padding(16.dp, 6.dp))
        "stats" -> Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            b.optJSONArray("items")?.list()?.forEach { s ->
                Column(Modifier.weight(1f).background(Soft, androidx.compose.foundation.shape.RoundedCornerShape(10.dp)).padding(10.dp)) {
                    Text(s.optString("label"), color = Mute, fontSize = 11.sp, maxLines = 1); Text(s.optString("value"), fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                }
            }
        }
        "chips" -> {
            val items = b.optJSONArray("items")?.list() ?: emptyList()
            val sel = items.indexOfFirst { it.optBoolean("on") }.coerceAtLeast(0)
            FilterRow(items.map { it.optString("label") + if (it.optString("count").isNotEmpty()) " ${it.optString("count")}" else "" }, sel) { linkNav(items[it].optJSONObject("target"), curP, nav) }
        }
        "link" -> GhostBtn(b.optString("text"), Modifier.fillMaxWidth().padding(12.dp, 4.dp)) { linkNav(b.optJSONObject("target"), curP, nav) }
        "item" -> {
            val tags = b.optJSONArray("tags")?.list()?.joinToString(" · ") { it.optString("t") } ?: ""
            val acts = b.optJSONArray("actions")?.list() ?: emptyList()
            var pending by remember { mutableStateOf<JSONObject?>(null) }
            Column {
                RowCard(b.optString("title"), listOf(b.optString("sub"), tags).filter { it.isNotEmpty() }.joinToString("\n"), b.optString("amt"), "",
                    if (b.optJSONObject("link") != null) ({ linkNav(b.optJSONObject("link"), curP, nav) }) else null)
                if (acts.isNotEmpty()) Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    acts.forEach { a ->
                        val risky = riskWord(a.optString("label")) != null
                        Text(a.optString("label"), color = if (risky) Red else Blue, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                            modifier = Modifier.clickable { if (risky) pending = a else sc.launch { if (postAction(ctx, curP, curQ, a, emptyMap())) reload() } }.padding(8.dp))
                    }
                }
            }
            pending?.let { a ->
                val w = riskWord(a.optString("label")) ?: "DELETE"
                ConfirmDialog(a.optString("label"), "This action can't be undone.", w, a.optString("label"), onDismiss = { pending = null }) {
                    pending = null; sc.launch { if (postAction(ctx, curP, curQ, a, emptyMap())) reload() }
                }
            }
        }
        "table" -> {
            val rows = b.optJSONArray("rows")?.list() ?: emptyList()
            val heads = b.optJSONArray("heads")?.list0() ?: emptyList()
            rows.forEach { row ->
                val cells = row.optJSONArray("cells")?.list0() ?: emptyList()
                val title = cells.firstOrNull { it.isNotBlank() } ?: ""
                val sub = cells.drop(1).mapIndexed { i, c -> if (c.isBlank()) "" else (heads.getOrNull(i + 1)?.let { "$it: " } ?: "") + c }.filter { it.isNotEmpty() }.joinToString("\n")
                RowCard(title, sub, "", "", if (row.optJSONObject("link") != null) ({ linkNav(row.optJSONObject("link"), curP, nav) }) else null)
            }
        }
        "form" -> FormBlock(b, curP, curQ, reload)
    }
}

fun JSONArray.list0(): List<String> = (0 until length()).map { optString(it) }

fun riskWord(label: String): String? {
    val l = label.lowercase()
    return when {
        "restore" in l -> "RESTORE"
        "cancel" in l || "terminate" in l -> "CANCEL"
        "delete" in l || "remove" in l -> "DELETE"
        else -> null
    }
}

suspend fun postAction(ctx: android.content.Context, curP: String, curQ: String, a: JSONObject, vals: Map<String, String>): Boolean {
    val fields = JSONArray()
    (a.optJSONArray("hidden") ?: JSONArray()).list().forEach { fields.put(JSONArray().put(it.optString("name")).put(it.optString("value"))) }
    vals.forEach { (k, v) -> fields.put(JSONArray().put(k).put(v)) }
    if (a.optString("name").isNotEmpty()) fields.put(JSONArray().put(a.optString("name")).put(a.optString("value")))
    val tp = a.optJSONObject("target")?.optString("p")?.ifEmpty { null } ?: curP
    val tq = a.optJSONObject("target")?.optString("q") ?: curQ
    return doAct(ctx) { Api.call("page_post", body = mapOf("p" to tp, "q" to tq, "fields" to fields)) }
}

@Composable
fun FormBlock(b: JSONObject, curP: String, curQ: String, reload: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    val fields = b.optJSONArray("fields")?.list() ?: emptyList()
    val vals = remember { mutableStateMapOf<String, String>().also { m -> fields.forEach { f ->
        if (f.optString("type") == "checkbox") m[f.optString("name")] = if (f.optBoolean("checked")) f.optString("value") else "" else m[f.optString("name")] = f.optString("value") } } }
    var pending by remember { mutableStateOf<JSONObject?>(null) }
    val hidden = b.optJSONArray("hidden") ?: JSONArray()
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        fields.forEach { f ->
            val n = f.optString("name"); val t = f.optString("type"); val label = f.optString("label").ifEmpty { n }
            when (t) {
                "file" -> {}
                "checkbox" -> Row(Modifier.fillMaxWidth().clickable { vals[n] = if (vals[n].isNullOrEmpty()) f.optString("value") else "" }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(!vals[n].isNullOrEmpty(), { vals[n] = if (it) f.optString("value") else "" }); Text(label, fontSize = 14.sp)
                }
                "select" -> {
                    val opts = f.optJSONArray("options")?.list0pairs() ?: emptyList()
                    var open by remember { mutableStateOf(false) }
                    Box {
                        OutlinedTextField(opts.firstOrNull { it.first == vals[n] }?.second ?: (vals[n] ?: ""), {}, readOnly = true, label = { Text(label) }, modifier = Modifier.fillMaxWidth().clickable { open = true }, enabled = false)
                        DropdownMenu(open, { open = false }) { opts.forEach { o -> DropdownMenuItem(text = { Text(o.second) }, onClick = { vals[n] = o.first; open = false }) } }
                    }
                }
                else -> Field(label, vals[n] ?: "", { vals[n] = it }, pw = t == "password", lines = if (t == "textarea") 4 else 1)
            }
        }
        b.optJSONArray("buttons")?.list()?.forEach { btn ->
            val risky = riskWord(btn.optString("label")) != null
            Btn(btn.optString("label"), if (risky) Red else Blue, Modifier.fillMaxWidth()) {
                val a = JSONObject(btn.toString()).put("hidden", hidden).put("target", b.optJSONObject("target"))
                if (risky) pending = a else sc.launch { if (postAction(ctx, curP, curQ, a, vals.filter { it.value.isNotEmpty() || fields.any { f -> f.optString("name") == it.key && f.optString("type") != "checkbox" } })) reload() }
            }
        }
    }
    pending?.let { a ->
        ConfirmDialog(a.optString("label"), "This action can't be undone.", riskWord(a.optString("label")) ?: "DELETE", a.optString("label"), onDismiss = { pending = null }) {
            pending = null; sc.launch { if (postAction(ctx, curP, curQ, a, vals.filter { it.value.isNotEmpty() })) reload() }
        }
    }
}

fun JSONArray.list0pairs(): List<Pair<String, String>> = (0 until length()).map { val a = getJSONArray(it); a.optString(0) to a.optString(1) }
