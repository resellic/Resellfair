@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.resellfair.admin

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.security.MessageDigest

data class Route(val k: String, val a: String = "", val b: String = "")
typealias Nav = (Route) -> Unit

/* ------------------------------ HOME ------------------------------ */
@Composable
fun HomeScreen(nav: Nav, goTab: (Int, Int) -> Unit) {
    val (r, retry) = useApi("dash") { Api.call("dash") }
    var per by remember { mutableIntStateOf(1) }
    val keys = listOf("today", "month", "year", "all")
    /* income / expenses / bars for the chosen period; falls back to the dash numbers if the site API is not updated yet */
    val (rc, _) = useApi("homechart${keys[per]}") { Api.call("home_chart", mapOf("p" to keys[per])) }
    Body(r, retry) { d ->
        val ch = (rc as? Res.Ok)?.j
        val income = ch?.optDouble("income") ?: d.optDouble(listOf("today", "month", "year", "all")[per])
        val expenses = ch?.optDouble("expenses") ?: d.optDouble("reg_cost")
        val bars = ch?.optJSONArray("bars")?.let { a -> (0 until a.length()).map { a.optDouble(it) } } ?: emptyList()
        Page {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(Navy, Blue)))) {
                Row(Modifier.fillMaxWidth()) {
                    listOf("Today", "Month", "Year", "All").forEachIndexed { i, t ->
                        Column(Modifier.weight(1f).clickable { per = i }.padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(t, color = Color.White.copy(alpha = if (i == per) 1f else 0.7f), fontSize = 14.sp, maxLines = 1)
                            Spacer(Modifier.height(9.dp))
                            Box(Modifier.fillMaxWidth().height(3.dp).background(if (i == per) Color.White else Color.Transparent))
                        }
                    }
                }
                Column(Modifier.padding(16.dp)) {
                    Text("Income", color = Pale, fontSize = 13.sp)
                    Text(money(income), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(10.dp))
                    val mx = (bars.maxOrNull() ?: 0.0).let { if (it <= 0) 1.0 else it }
                    Row(Modifier.fillMaxWidth().height(54.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
                        bars.forEachIndexed { i, b ->
                            Box(Modifier.weight(1f).fillMaxHeight((b / mx).toFloat().coerceIn(0.06f, 1f)).clip(RoundedCornerShape(3.dp))
                                .background(Color.White.copy(alpha = if (i == bars.lastIndex) 1f else 0.45f)))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.25f)))
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Expenses", money(expenses), Modifier.weight(1f))
                        Stat("Client balance", money(d.optDouble("client_balance")), Modifier.weight(1f))
                    }
                }
            }
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("📦", "Pending orders", d.optInt("pending_orders"), Modifier.weight(1f)) { goTab(1, 1) }
                Tile("💳", "Pending payments", d.optInt("pending_trx"), Modifier.weight(1f)) { goTab(2, 1) }
            }
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("🧾", "Unpaid invoices", d.optInt("unpaid_invoices"), Modifier.weight(1f)) { nav(Route("page", "invoices.php")) }
                Tile("💬", "Open tickets", d.optInt("open_tickets"), Modifier.weight(1f)) { nav(Route("tickets", "0")) }
            }
            val recent = (d.optJSONArray("recent")?.list() ?: emptyList()).take(5)
            CardBox("Last orders", recent.size, "See all", { goTab(1, 0) }) {
                recent.forEach { o ->
                    ListRow(o.optString("order_no"), o.optString("email") + " · " + o.optString("item"), money(o.optDouble("total")), o.optString("status")) { goTab(1, 0) }
                }
            }
        }
    }
}

@Composable
fun Tile(icon: String, label: String, n: Int, m: Modifier, onClick: () -> Unit) {
    Column(m.clip(RoundedCornerShape(18.dp)).background(Color.White).clickable { onClick() }.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(Soft), contentAlignment = Alignment.Center) { Text(icon, fontSize = 17.sp) }
            Spacer(Modifier.width(10.dp))
            Text(label, color = Mute, fontSize = 13.sp, lineHeight = 15.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text("$n", fontSize = 28.sp, fontWeight = FontWeight.Medium, color = Ink)
    }
}

@Composable
fun Stat(label: String, value: String, m: Modifier) {
    Column(m) { Text(label, color = Pale, fontSize = 12.sp); Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium) }
}

/* ------------------------------ ORDERS ------------------------------ */
@Composable
fun OrdersScreen(nav: Nav, filter: Int, setFilter: (Int) -> Unit) {
    val keys = listOf("", "pending", "completed", "cancelled")
    val (r, retry) = useApi("orders$filter") { Api.call("orders", mapOf("f" to keys[filter])) }
    var sheet by remember { mutableStateOf<JSONObject?>(null) }
    Column(Modifier.fillMaxSize()) {
        FilterRow(listOf("All", "Pending", "Paid", "Cancelled"), filter, setFilter)
        Body(r, retry) { j ->
            val rows = j.optJSONArray("data")?.list() ?: emptyList()
            if (rows.isEmpty()) Empty("No orders") else Page {
                CardBox("Orders", rows.size) {
                    rows.forEach { o ->
                        val pending = o.optString("status") in listOf("pending", "processing") && o.optString("src") == "o"
                        ListRow(o.optString("order_no"), o.optString("email") + " · " + o.optString("item"), money(o.optDouble("total")),
                            o.optString("status")) { if (pending) sheet = o else if (o.optString("src") == "o") nav(Route("order", o.optString("id"))) }
                    }
                }
            }
        }
    }
    sheet?.let { o -> OrderActions(o, onClose = { sheet = null }, onDone = { sheet = null; retry() }, open = { sheet = null; nav(Route("order", o.optString("id"))) }) }
}

@Composable
fun OrderActions(o: JSONObject, onClose: () -> Unit, onDone: () -> Unit, open: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var typed by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = Color.White) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Text(o.optString("order_no"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(o.optString("email") + " · " + money(o.optDouble("total")), color = Mute)
            Spacer(Modifier.height(14.dp))
            Text("Type PAID to approve, or CANCEL to cancel this order", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(typed, { typed = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Approve", if (typed.trim() == "PAID") Green else Mute, Modifier.weight(1f)) {
                    if (typed.trim() == "PAID") sc.launch { if (doAct(ctx) { Api.call("order_do", body = mapOf("act" to "provision", "order_id" to o.optString("id"))) }) onDone() }
                }
                Btn("Cancel order", if (typed.trim() == "CANCEL") Red else Mute, Modifier.weight(1f)) {
                    if (typed.trim() == "CANCEL") sc.launch { if (doAct(ctx) { Api.call("order_do", body = mapOf("act" to "cancel_order", "order_id" to o.optString("id"))) }) onDone() }
                }
            }
            Spacer(Modifier.height(10.dp)); GhostBtn("View order", Modifier.fillMaxWidth()) { open() }
        }
    }
}

@Composable
fun OrderDetail(id: String) {
    val (r, retry) = useApi("order$id") { Api.call("order", mapOf("id" to id)) }
    Body(r, retry) { j ->
        val o = j.getJSONObject("order")
        Page {
            RowCard(o.optString("order_no"), o.optString("email") + "\n" + o.optString("created_at"), money(o.optDouble("total")), o.optString("status"))
            Text("Items", fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp))
            j.optJSONArray("items")?.list()?.forEach {
                RowCard(it.optString("domain"), it.optString("action") + " · " + it.optString("years") + " yr", money(it.optDouble("price")), it.optString("provision_status"))
            }
            Text("Invoices", fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp))
            j.optJSONArray("invoices")?.list()?.forEach { RowCard(it.optString("invoice_no"), "", money(it.optDouble("total")), it.optString("status")) }
        }
    }
}

/* ------------------------------ PAYMENTS ------------------------------ */
@Composable
fun PaymentsScreen(nav: Nav, start: Int = 0) {
    var f by remember(start) { mutableIntStateOf(start) }
    val (r, retry) = useApi("pay$f") { if (f == 1) Api.call("pending_trx") else Api.call("pay_list") }
    var sheet by remember { mutableStateOf<JSONObject?>(null) }
    var info by remember { mutableStateOf<JSONObject?>(null) }
    Column(Modifier.fillMaxSize()) {
        FilterRow(listOf("All", "Pending", "Paid"), f) { f = it }
        Body(r, retry) { j ->
            var rows = j.optJSONArray("data")?.list() ?: emptyList()
            if (f == 2) rows = rows.filter { it.optString("status") == "paid" }
            if (rows.isEmpty()) Empty("No payments") else Page {
                CardBox("Payments", rows.size) {
                    rows.forEach { p ->
                        val pendingTrx = f == 1
                        val who = p.optString("email").ifEmpty { p.optString("customer_email") }
                        val method = p.optString("method").ifEmpty { p.optString("gateway_slug") }
                        val st = if (pendingTrx) "pending" else p.optString("status")
                        ListRow(who.ifEmpty { "—" }, method + " · " + p.optString("trx_id") + " · " + p.optString("created_at"),
                            money(p.optDouble("pay_amount", p.optDouble("amount"))), st) { if (pendingTrx) sheet = p else info = p }
                    }
                }
            }
        }
    }
    sheet?.let { p -> PayActions(p, { sheet = null }) { sheet = null; retry() } }
    info?.let { p ->
        AlertDialog(onDismissRequest = { info = null }, containerColor = Color.White,
            title = { Text(p.optString("order_id").ifEmpty { "Payment" }, fontWeight = FontWeight.Bold) },
            text = { Text("${p.optString("customer_name")}\n${p.optString("customer_email")}\n${p.optString("customer_phone")}\nTrxID: ${p.optString("trx_id")}\nPaid: ${p.optString("paid_at")}") },
            confirmButton = { TextButton({ info = null }) { Text("Close") } })
    }
}

@Composable
fun PayActions(p: JSONObject, onClose: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var typed by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = Color.White) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Text(money(p.optDouble("amount")) + " · " + p.optString("method"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(p.optString("email") + "\nInvoice " + p.optString("invoice_no") + " · TrxID " + p.optString("trx_id"), color = Mute)
            Spacer(Modifier.height(14.dp))
            Text("Type PAID to approve, or CANCEL to reject", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(typed, { typed = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Approve", if (typed.trim() == "PAID") Green else Mute, Modifier.weight(1f)) {
                    if (typed.trim() == "PAID") sc.launch { if (doAct(ctx) { Api.call("trx_do", body = mapOf("id" to p.optString("id"), "act" to "approve")) }) onDone() }
                }
                Btn("Reject", if (typed.trim() == "CANCEL") Red else Mute, Modifier.weight(1f)) {
                    if (typed.trim() == "CANCEL") sc.launch { if (doAct(ctx) { Api.call("trx_do", body = mapOf("id" to p.optString("id"), "act" to "reject")) }) onDone() }
                }
            }
        }
    }
}

/* ------------------------------ CLIENTS ------------------------------ */
@Composable
fun ClientsScreen(nav: Nav) {
    var q by remember { mutableStateOf("") }
    var qq by remember { mutableStateOf("") }
    val (r, retry) = useApi("clients$qq") { Api.call("clients", mapOf("q" to qq)) }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { q = it; if (it.isEmpty() || it.length > 2) qq = it }, singleLine = true, placeholder = { Text("Search clients") },
            modifier = Modifier.fillMaxWidth().padding(12.dp, 8.dp))
        Body(r, retry) { j ->
            val rows = j.optJSONArray("data")?.list() ?: emptyList()
            if (rows.isEmpty()) Empty("No clients") else Page {
                CardBox("Clients", rows.size) {
                    rows.forEach { c ->
                        ListRow((c.optString("first_name") + " " + c.optString("last_name")).trim().ifEmpty { c.optString("email") }, c.optString("email"), money(c.optDouble("balance")), c.optString("status")) { nav(Route("client", c.optString("id"))) }
                    }
                }
            }
        }
    }
}

fun sha256(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

@Composable
fun ClientDetail(id: String, back: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    val (r, retry) = useApi("client$id") { Api.call("client", mapOf("id" to id)) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    Body(r, retry) { j ->
        val c = j.getJSONObject("client")
        Page {
            RowCard((c.optString("first_name") + " " + c.optString("last_name")).trim(), c.optString("email") + "\n" + c.optString("phone"), money(c.optDouble("balance")), c.optString("status"))
            RowCard("Domains / Hosting", "", j.optInt("domains").toString() + " / " + j.optInt("hosting"))
            Spacer(Modifier.height(10.dp))
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Login as client", Blue, Modifier.fillMaxWidth()) {
                    val u = "$API?a=web&to=client%2Findex.php&h=" + sha256(Store.token)
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                }
                GhostBtn("Edit client", Modifier.fillMaxWidth()) { edit = true }
                Btn("Delete client", Red, Modifier.fillMaxWidth()) { del = true }
            }
        }
        if (edit) EditClient(c, { edit = false }) { edit = false; retry() }
        if (del) ConfirmDialog("Delete client", "This permanently deletes ${c.optString("email")} and cannot be undone.", "DELETE", "Delete", onDismiss = { del = false }) {
            sc.launch {
                val ok = doAct(ctx) { Api.call("page_post", body = mapOf("p" to "users.php", "fields" to org.json.JSONArray().put(org.json.JSONArray().put("id").put(id)).put(org.json.JSONArray().put("delete_user").put("1")))) }
                if (ok) { del = false; back() }
            }
        }
    }
}

@Composable
fun EditClient(c: JSONObject, onClose: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    val keys = listOf("first_name", "last_name", "company", "email", "phone", "address1", "city", "state", "postcode", "country")
    val vals = remember { mutableStateMapOf<String, String>().also { m -> keys.forEach { m[it] = c.optString(it) } } }
    AlertDialog(onDismissRequest = onClose, containerColor = Color.White, title = { Text("Edit client", fontWeight = FontWeight.Bold) },
        text = { Column(Modifier.verticalScrollCompat(), verticalArrangement = Arrangement.spacedBy(6.dp)) { keys.forEach { k -> Field(k.replace('_', ' ').replaceFirstChar { it.uppercase() }, vals[k] ?: "", { vals[k] = it }) } } },
        confirmButton = { TextButton({ sc.launch { val b = mutableMapOf<String, Any?>("id" to c.optString("id")); keys.forEach { b[it] = vals[it] }; if (doAct(ctx) { Api.call("client_save", body = b) }) onDone() } }) { Text("Save", color = Blue, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClose) { Text("Close", color = Mute) } })
}

@Composable
fun Modifier.verticalScrollCompat(): Modifier = this.then(Modifier.heightIn(max = 420.dp)).verticalScroll(androidx.compose.foundation.rememberScrollState())
