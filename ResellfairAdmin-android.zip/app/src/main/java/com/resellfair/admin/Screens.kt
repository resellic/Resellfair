@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.resellfair.admin

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.security.MessageDigest

data class Route(val k: String, val a: String = "", val b: String = "")
typealias Nav = (Route) -> Unit

/* ------------------------------ HOME ------------------------------ */
@Composable
fun HomeScreen(nav: Nav, goTab: (Int, Int) -> Unit) {
    val (r, retry) = useApi("dash") { Api.call("dash") }
    val (ro, _) = useApi("homeorders") { Api.call("orders") }
    Body(r, retry) { d ->
        Page {
            Column(Modifier.padding(12.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Navy).padding(16.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    Stat("Income · month", money(d.optDouble("month")), Modifier.weight(1f))
                    Stat("Expenses", money(d.optDouble("reg_cost")), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Stat("Client balance", money(d.optDouble("client_balance")), Modifier.fillMaxWidth())
            }
            Column(Modifier.padding(horizontal = 12.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Soft)) {
                CountRow("Pending orders", d.optInt("pending_orders")) { goTab(1, 1) }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
                CountRow("Open tickets", d.optInt("open_tickets")) { nav(Route("tickets", "1")) }
            }
            Text("Last orders", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp))
            if (ro is Res.Ok) ro.j.optJSONArray("data")?.list()?.take(6)?.forEach { o ->
                RowCard(o.optString("order_no"), o.optString("email") + " · " + o.optString("item"), money(o.optDouble("total")), o.optString("status")) { goTab(1, 0) }
            }
        }
    }
}

@Composable
fun Stat(label: String, value: String, m: Modifier) {
    Column(m) { Text(label, color = Color(0xFFB8C4F0), fontSize = 12.sp); Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun CountRow(label: String, n: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontWeight = FontWeight.Medium, fontSize = 15.sp)
        Text("$n", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(if (n > 0) Blue else Mute).padding(horizontal = 10.dp, vertical = 3.dp))
        Text("  ›", color = Mute, fontSize = 20.sp)
    }
}

/* ------------------------------ ORDERS ------------------------------ */
@Composable
fun OrdersScreen(nav: Nav, filter: Int, setFilter: (Int) -> Unit) {
    val keys = listOf("", "pending", "completed", "cancelled")
    val (r, retry) = useApi("orders$filter") { Api.call("orders", mapOf("f" to keys[filter])) }
    var sheet by remember { mutableStateOf<JSONObject?>(null) }
    Column(Modifier.fillMaxSize()) {
        FilterRow(listOf("All", "Pending", "Paid", "Cancelled"), filter, setFilter)
        Body(r, retry) { j ->
            val rows = j.optJSONArray("data")?.list() ?: emptyList()
            if (rows.isEmpty()) Empty("No orders") else Page {
                rows.forEach { o ->
                    val pending = o.optString("status") in listOf("pending", "processing") && o.optString("src") == "o"
                    RowCard(o.optString("order_no"), o.optString("email") + " · " + o.optString("item"), money(o.optDouble("total")),
                        o.optString("status")) { if (pending) sheet = o else if (o.optString("src") == "o") nav(Route("order", o.optString("id"))) }
                }
            }
        }
    }
    sheet?.let { o -> OrderActions(o, onClose = { sheet = null }, onDone = { sheet = null; retry() }, open = { sheet = null; nav(Route("order", o.optString("id"))) }) }
}

@Composable
fun OrderActions(o: JSONObject, onClose: () -> Unit, onDone: () -> Unit, open: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var typed by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = Color.White) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Text(o.optString("order_no"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(o.optString("email") + " · " + money(o.optDouble("total")), color = Mute)
            Spacer(Modifier.height(14.dp))
            Text("Type PAID to approve, or CANCEL to cancel this order", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(typed, { typed = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Approve", if (typed.trim() == "PAID") Green else Mute, Modifier.weight(1f)) {
                    if (typed.trim() == "PAID") sc.launch { if (doAct(ctx) { Api.call("order_do", body = mapOf("act" to "provision", "order_id" to o.optString("id"))) }) onDone() }
                }
                Btn("Cancel order", if (typed.trim() == "CANCEL") Red else Mute, Modifier.weight(1f)) {
                    if (typed.trim() == "CANCEL") sc.launch { if (doAct(ctx) { Api.call("order_do", body = mapOf("act" to "cancel_order", "order_id" to o.optString("id"))) }) onDone() }
                }
            }
            Spacer(Modifier.height(10.dp)); GhostBtn("View order", Modifier.fillMaxWidth()) { open() }
        }
    }
}

@Composable
fun OrderDetail(id: String) {
    val (r, retry) = useApi("order$id") { Api.call("order", mapOf("id" to id)) }
    Body(r, retry) { j ->
        val o = j.getJSONObject("order")
        Page {
            RowCard(o.optString("order_no"), o.optString("email") + "\n" + o.optString("created_at"), money(o.optDouble("total")), o.optString("status"))
            Text("Items", fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp))
            j.optJSONArray("items")?.list()?.forEach {
                RowCard(it.optString("domain"), it.optString("action") + " · " + it.optString("years") + " yr", money(it.optDouble("price")), it.optString("provision_status"))
            }
            Text("Invoices", fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp))
            j.optJSONArray("invoices")?.list()?.forEach { RowCard(it.optString("invoice_no"), "", money(it.optDouble("total")), it.optString("status")) }
        }
    }
}

/* ------------------------------ PAYMENTS ------------------------------ */
@Composable
fun PaymentsScreen(nav: Nav) {
    var f by remember { mutableIntStateOf(0) }
    val (r, retry) = useApi("pay$f") { if (f == 1) Api.call("pending_trx") else Api.call("pay_list") }
    var sheet by remember { mutableStateOf<JSONObject?>(null) }
    var info by remember { mutableStateOf<JSONObject?>(null) }
    Column(Modifier.fillMaxSize()) {
        FilterRow(listOf("All", "Pending", "Paid"), f) { f = it }
        Body(r, retry) { j ->
            var rows = j.optJSONArray("data")?.list() ?: emptyList()
            if (f == 2) rows = rows.filter { it.optString("status") == "paid" }
            if (rows.isEmpty()) Empty("No payments") else Page {
                rows.forEach { p ->
                    val pendingTrx = f == 1
                    val who = p.optString("email").ifEmpty { p.optString("customer_email") }
                    val method = p.optString("method").ifEmpty { p.optString("gateway_slug") }
                    val st = if (pendingTrx) "pending" else p.optString("status")
                    RowCard(who.ifEmpty { "—" }, method + " · " + p.optString("trx_id") + " · " + p.optString("created_at"),
                        money(p.optDouble("pay_amount", p.optDouble("amount"))), st) { if (pendingTrx) sheet = p else info = p }
                }
            }
        }
    }
    sheet?.let { p -> PayActions(p, { sheet = null }) { sheet = null; retry() } }
    info?.let { p ->
        AlertDialog(onDismissRequest = { info = null }, containerColor = Color.White,
            title = { Text(p.optString("order_id").ifEmpty { "Payment" }, fontWeight = FontWeight.Bold) },
            text = { Text("${p.optString("customer_name")}\n${p.optString("customer_email")}\n${p.optString("customer_phone")}\nTrxID: ${p.optString("trx_id")}\nPaid: ${p.optString("paid_at")}") },
            confirmButton = { TextButton({ info = null }) { Text("Close") } })
    }
}

@Composable
fun PayActions(p: JSONObject, onClose: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var typed by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = Color.White) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Text(money(p.optDouble("amount")) + " · " + p.optString("method"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(p.optString("email") + "\nInvoice " + p.optString("invoice_no") + " · TrxID " + p.optString("trx_id"), color = Mute)
            Spacer(Modifier.height(14.dp))
            Text("Type PAID to approve, or CANCEL to reject", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(typed, { typed = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Approve", if (typed.trim() == "PAID") Green else Mute, Modifier.weight(1f)) {
                    if (typed.trim() == "PAID") sc.launch { if (doAct(ctx) { Api.call("trx_do", body = mapOf("id" to p.optString("id"), "act" to "approve")) }) onDone() }
                }
                Btn("Reject", if (typed.trim() == "CANCEL") Red else Mute, Modifier.weight(1f)) {
                    if (typed.trim() == "CANCEL") sc.launch { if (doAct(ctx) { Api.call("trx_do", body = mapOf("id" to p.optString("id"), "act" to "reject")) }) onDone() }
                }
            }
        }
    }
}

/* ------------------------------ CLIENTS ------------------------------ */
@Composable
fun ClientsScreen(nav: Nav) {
    var q by remember { mutableStateOf("") }
    var qq by remember { mutableStateOf("") }
    val (r, retry) = useApi("clients$qq") { Api.call("clients", mapOf("q" to qq)) }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { q = it; if (it.isEmpty() || it.length > 2) qq = it }, singleLine = true, placeholder = { Text("Search clients") },
            modifier = Modifier.fillMaxWidth().padding(12.dp, 8.dp))
        Body(r, retry) { j ->
            val rows = j.optJSONArray("data")?.list() ?: emptyList()
            if (rows.isEmpty()) Empty("No clients") else Page {
                rows.forEach { c ->
                    RowCard((c.optString("first_name") + " " + c.optString("last_name")).trim().ifEmpty { c.optString("email") }, c.optString("email"), money(c.optDouble("balance")), c.optString("status")) { nav(Route("client", c.optString("id"))) }
                }
            }
        }
    }
}

fun sha256(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

@Composable
fun ClientDetail(id: String, back: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    val (r, retry) = useApi("client$id") { Api.call("client", mapOf("id" to id)) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    Body(r, retry) { j ->
        val c = j.getJSONObject("client")
        Page {
            RowCard((c.optString("first_name") + " " + c.optString("last_name")).trim(), c.optString("email") + "\n" + c.optString("phone"), money(c.optDouble("balance")), c.optString("status"))
            RowCard("Domains / Hosting", "", j.optInt("domains").toString() + " / " + j.optInt("hosting"))
            Spacer(Modifier.height(10.dp))
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Login as client", Blue, Modifier.fillMaxWidth()) {
                    val u = "$API?a=web&to=client%2Findex.php&h=" + sha256(Store.token)
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                }
                GhostBtn("Edit client", Modifier.fillMaxWidth()) { edit = true }
                Btn("Delete client", Red, Modifier.fillMaxWidth()) { del = true }
            }
        }
        if (edit) EditClient(c, { edit = false }) { edit = false; retry() }
        if (del) ConfirmDialog("Delete client", "This permanently deletes ${c.optString("email")} and cannot be undone.", "DELETE", "Delete", onDismiss = { del = false }) {
            sc.launch {
                val ok = doAct(ctx) { Api.call("page_post", body = mapOf("p" to "users.php", "fields" to org.json.JSONArray().put(org.json.JSONArray().put("id").put(id)).put(org.json.JSONArray().put("delete_user").put("1")))) }
                if (ok) { del = false; back() }
            }
        }
    }
}

@Composable
fun EditClient(c: JSONObject, onClose: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    val keys = listOf("first_name", "last_name", "company", "email", "phone", "address1", "city", "state", "postcode", "country")
    val vals = remember { mutableStateMapOf<String, String>().also { m -> keys.forEach { m[it] = c.optString(it) } } }
    AlertDialog(onDismissRequest = onClose, containerColor = Color.White, title = { Text("Edit client", fontWeight = FontWeight.Bold) },
        text = { Column(Modifier.verticalScrollCompat(), verticalArrangement = Arrangement.spacedBy(6.dp)) { keys.forEach { k -> Field(k.replace('_', ' ').replaceFirstChar { it.uppercase() }, vals[k] ?: "", { vals[k] = it }) } } },
        confirmButton = { TextButton({ sc.launch { val b = mutableMapOf<String, Any?>("id" to c.optString("id")); keys.forEach { b[it] = vals[it] }; if (doAct(ctx) { Api.call("client_save", body = b) }) onDone() } }) { Text("Save", color = Blue, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClose) { Text("Close", color = Mute) } })
}

@Composable
fun Modifier.verticalScrollCompat(): Modifier = this.then(Modifier.heightIn(max = 420.dp)).verticalScroll(androidx.compose.foundation.rememberScrollState())
