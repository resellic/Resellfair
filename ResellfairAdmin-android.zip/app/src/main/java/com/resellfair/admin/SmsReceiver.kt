package com.resellfair.admin

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Runs silently in the background: forwards every incoming SMS to the site's payment automation. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        Store.init(context)
        if (Store.payToken.isEmpty()) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val grouped = msgs.groupBy { it.originatingAddress ?: "" }
        val at = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val pr = goAsync()
        Thread {
            try {
                for ((sender, parts) in grouped) {
                    val body = parts.joinToString("") { it.messageBody ?: "" }
                    var ok = false; var n = 0
                    while (!ok && n < 4) { ok = Api.postSms(sender, body, at); if (!ok) Thread.sleep(2000L * (++n)) }
                }
            } finally { pr.finish() }
        }.start()
    }
}
