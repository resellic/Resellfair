package com.resellfair.admin

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

val Navy = Color(0xFF16286A)
val Blue = Color(0xFF2563EB)
val Ink = Color(0xFF0F172A)
val Mute = Color(0xFF64748B)
val Line = Color(0xFFE2E8F0)
val Soft = Color(0xFFF1F5F9)
val Red = Color(0xFFDC2626)
val Green = Color(0xFF16A34A)
val Amber = Color(0xFFD97706)

object Session {
    var loggedIn by mutableStateOf(false)
    var locked by mutableStateOf(true)
    var unread by mutableIntStateOf(0)
}

sealed class Res {
    object Loading : Res()
    class Ok(val j: JSONObject) : Res()
    class Err(val m: String) : Res()
}

@Composable
fun useApi(key: Any, f: () -> JSONObject): Pair<Res, () -> Unit> {
    var tick by remember { mutableIntStateOf(0) }
    var res by remember(key) { mutableStateOf<Res>(Res.Loading) }
    LaunchedEffect(key, tick) {
        res = try { Res.Ok(withContext(Dispatchers.IO) { f() }) }
        catch (e: ApiError) { if (e.code == 401) Session.loggedIn = false; Res.Err(e.message ?: "Error") }
        catch (e: Exception) { Res.Err("No connection") }
    }
    return res to { tick++ }
}

/** Runs an action off the main thread, toasts the server message, calls onDone on success. */
suspend fun doAct(ctx: Context, f: () -> JSONObject): Boolean {
    return try {
        val j = withContext(Dispatchers.IO) { f() }
        val m = j.optString("message", "")
        if (m.isNotEmpty()) Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
        true
    } catch (e: ApiError) {
        if (e.code == 401) Session.loggedIn = false
        Toast.makeText(ctx, e.message ?: "Failed", Toast.LENGTH_LONG).show(); false
    } catch (e: Exception) { Toast.makeText(ctx, "No connection", Toast.LENGTH_LONG).show(); false }
}

fun money(v: Double) = "$" + String.format("%,.2f", v)

@Composable
fun Header(title: String, back: (() -> Unit)? = null, bell: Boolean = false, onBell: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(Navy).statusBarsPadding().height(56.dp).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back != null) Box(Modifier.size(44.dp).clickable { back() }, contentAlignment = Alignment.Center) { Text("‹", color = Color.White, fontSize = 30.sp) }
        else Spacer(Modifier.width(12.dp))
        Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (bell) Box(Modifier.size(48.dp).clickable { onBell() }, contentAlignment = Alignment.Center) {
            Text("🔔", fontSize = 20.sp)
            if (Session.unread > 0) Box(Modifier.align(Alignment.TopEnd).padding(top = 6.dp, end = 4.dp).clip(CircleShape).background(Red).defaultMinSize(18.dp, 18.dp), contentAlignment = Alignment.Center) {
                Text(if (Session.unread > 99) "99+" else "${Session.unread}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
            }
        }
    }
}

/** One-line filter row: no box, never wraps or scrolls, text shrinks to fit. */
@Composable
fun FilterRow(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
        items.forEachIndexed { i, t ->
            Column(Modifier.weight(1f).clickable { onSel(i) }.padding(top = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(t, fontSize = if (items.size > 4) 12.sp else 14.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
                    color = if (i == sel) Blue else Mute, fontWeight = if (i == sel) FontWeight.Bold else FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(if (i == sel) 3.dp else 1.dp).background(if (i == sel) Blue else Line))
            }
        }
    }
}

@Composable
fun Chip(t: String, c: Color) {
    Text(t, color = c, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.12f)).padding(horizontal = 8.dp, vertical = 2.dp))
}

fun statusColor(s: String) = when (s.lowercase()) {
    "paid", "completed", "active", "success", "answered", "done" -> Green
    "pending", "processing", "review", "open", "customer_reply", "unpaid" -> Amber
    "cancelled", "failed", "closed", "rejected", "terminated", "expired" -> Red
    else -> Mute
}

@Composable
fun RowCard(title: String, sub: String, right: String = "", tag: String = "", onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(12.dp))
            .background(Color.White).border(BorderStroke(1.dp, Line), RoundedCornerShape(12.dp)).let { if (onClick != null) it.clickable { onClick() } else it }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = Mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Column(horizontalAlignment = Alignment.End) {
            if (right.isNotEmpty()) Text(right, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Ink)
            if (tag.isNotEmpty()) Chip(tag, statusColor(tag))
        }
    }
}

@Composable
fun Btn(text: String, color: Color = Blue, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(10.dp)).background(color).clickable { onClick() }.padding(vertical = 13.dp, horizontal = 16.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
fun GhostBtn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(10.dp)).background(Soft).clickable { onClick() }.padding(vertical = 13.dp, horizontal = 16.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
fun Empty(msg: String) { Text(msg, color = Mute, modifier = Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center) }

@Composable
fun Body(res: Res, retry: () -> Unit, content: @Composable (JSONObject) -> Unit) {
    when (res) {
        is Res.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Blue) }
        is Res.Err -> Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(res.m, color = Red, textAlign = TextAlign.Center); Spacer(Modifier.height(12.dp)); GhostBtn("Try again") { retry() }
        }
        is Res.Ok -> content(res.j)
    }
}

/** Typed-word confirmation for risky actions. */
@Composable
fun ConfirmDialog(title: String, text: String, word: String, action: String, color: Color = Red, onDismiss: () -> Unit, onOk: () -> Unit) {
    var typed by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color.White,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(text, color = Mute, fontSize = 14.sp); Spacer(Modifier.height(10.dp))
                Text("Type $word to confirm", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(typed, { typed = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(onClick = { if (typed.trim() == word) onOk() }, enabled = typed.trim() == word) { Text(action, color = if (typed.trim() == word) color else Mute, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = Mute) } }
    )
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, pw: Boolean = false, lines: Int = 1) {
    OutlinedTextField(
        value, onChange, label = { Text(label) }, modifier = modifier.fillMaxWidth(), singleLine = lines == 1, minLines = lines,
        visualTransformation = if (pw) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None
    )
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp), content = content)
}
