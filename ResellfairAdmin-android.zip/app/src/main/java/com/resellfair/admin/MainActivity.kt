package com.resellfair.admin

import android.Manifest
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import org.json.JSONObject

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.loggedIn = Store.token.isNotEmpty()
        Session.locked = true
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Blue)) { Root(this) } }
    }
    override fun onStop() { super.onStop(); if (Store.pin.isNotEmpty()) Session.locked = true }
}

@Composable
fun Root(act: FragmentActivity) {
    when {
        !Session.loggedIn -> LoginScreen()
        Session.locked -> LockScreen(act)
        else -> Shell(act)
    }
}

/* ------------------------------ LOGIN ------------------------------ */
@Composable
fun LoginScreen() {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var email by remember { mutableStateOf(Store.email) }
    var pw by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var ticket by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Color.White)) {
        Header("Resellfair Admin")
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Spacer(Modifier.height(12.dp))
            Text(if (ticket.isEmpty()) "Sign in" else "Verification", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            if (ticket.isEmpty()) {
                Field("Email", email, { email = it }); Field("Password", pw, { pw = it }, pw = true)
                Btn(if (busy) "Please wait…" else "Continue", Blue, Modifier.fillMaxWidth()) {
                    if (busy || email.isBlank() || pw.isEmpty()) return@Btn
                    busy = true
                    sc.launch {
                        try {
                            val j = withContext(Dispatchers.IO) { Api.call("login", body = mapOf("email" to email.trim(), "password" to pw, "device_id" to Store.deviceId, "device_name" to (Build.MODEL ?: "Android"))) }
                            ticket = j.optString("ticket"); secret = if (j.optString("step") == "totp_setup") j.optString("secret") else ""
                        } catch (e: ApiError) { android.widget.Toast.makeText(ctx, e.message, android.widget.Toast.LENGTH_LONG).show() }
                        catch (e: Exception) { android.widget.Toast.makeText(ctx, "No connection", android.widget.Toast.LENGTH_LONG).show() }
                        busy = false
                    }
                }
            } else {
                if (secret.isNotEmpty()) {
                    Text("Add this key to your Authenticator app, then enter the 6-digit code.", color = Mute)
                    androidx.compose.foundation.text.selection.SelectionContainer { Text(secret, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                } else Text("Enter the 6-digit code from your Authenticator app.", color = Mute)
                Field("Code", code, { code = it.filter { c -> c.isDigit() }.take(6) })
                Btn(if (busy) "Please wait…" else "Verify", Blue, Modifier.fillMaxWidth()) {
                    if (busy || code.length < 6) return@Btn
                    busy = true
                    sc.launch {
                        try {
                            val j = withContext(Dispatchers.IO) { Api.call("verify", body = mapOf("ticket" to ticket, "code" to code)) }
                            Store.email = email.trim(); Store.payToken = j.optString("pay_token"); Store.token = j.optString("token")
                            Session.loggedIn = true; Session.locked = Store.pin.isNotEmpty()
                        } catch (e: ApiError) { android.widget.Toast.makeText(ctx, e.message, android.widget.Toast.LENGTH_LONG).show() }
                        catch (e: Exception) { android.widget.Toast.makeText(ctx, "No connection", android.widget.Toast.LENGTH_LONG).show() }
                        busy = false
                    }
                }
            }
        }
    }
}

/* ------------------------------ LOCK ------------------------------ */
@Composable
fun LockScreen(act: FragmentActivity) {
    val setting = Store.pin.isEmpty()
    var first by remember { mutableStateOf("") }
    var cur by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val title = if (setting) (if (first.isEmpty()) "Create a PIN" else "Confirm PIN") else "Enter PIN"

    fun bio() {
        if (setting) return
        val pr = BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { Session.locked = false }
        })
        pr.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Resellfair Admin").setNegativeButtonText("Use PIN").build())
    }
    LaunchedEffect(setting) { if (!setting) bio() }

    fun press(d: String) {
        if (cur.length >= 4) return
        cur += d
        if (cur.length == 4) {
            if (setting) {
                if (first.isEmpty()) { first = cur; cur = "" }
                else if (first == cur) { Store.pin = cur; Session.locked = false } else { err = "PINs do not match"; first = ""; cur = "" }
            } else if (cur == Store.pin) Session.locked = false else { err = "Wrong PIN"; cur = "" }
        }
    }
    Column(Modifier.fillMaxSize().background(Color.White), horizontalAlignment = Alignment.CenterHorizontally) {
        Header("Resellfair Admin")
        Spacer(Modifier.height(40.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            repeat(4) { Box(Modifier.size(16.dp).clip(CircleShape).background(if (it < cur.length) Blue else Line)) }
        }
        Text(err, color = Red, modifier = Modifier.padding(top = 12.dp).height(24.dp))
        Spacer(Modifier.height(16.dp))
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫")
        keys.chunked(3).forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                r.forEach { k ->
                    Box(Modifier.size(72.dp).clip(CircleShape).background(if (k.isEmpty()) Color.Transparent else Soft)
                        .clickable(enabled = k.isNotEmpty()) { err = ""; if (k == "⌫") cur = cur.dropLast(1) else press(k) }, contentAlignment = Alignment.Center) {
                        Text(k, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        if (!setting) Text("Use fingerprint", color = Blue, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(16.dp).clickable { bio() })
    }
}

/* ------------------------------ SHELL ------------------------------ */
@Composable
fun Shell(act: FragmentActivity) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var stack by remember { mutableStateOf(listOf<Route>()) }
    var ordFilter by remember { mutableIntStateOf(0) }
    val nav: Nav = { stack = stack + it }
    val top = stack.lastOrNull()
    val topA = top?.a ?: ""
    val topB = top?.b ?: ""

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        val want = mutableListOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
        if (Build.VERSION.SDK_INT >= 33) want += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(want.toTypedArray())
    }
    /* Poll for new notices while the app is open and raise a system notification for each new one */
    LaunchedEffect(Unit) {
        while (true) {
            try {
                val j = withContext(Dispatchers.IO) { Api.call("notifs", if (Store.lastNotif >= 0) mapOf("since" to Store.lastNotif.toString()) else emptyMap()) }
                Session.unread = j.optInt("unread")
                val rows = j.optJSONArray("data")?.list() ?: emptyList()
                if (Store.lastNotif >= 0) rows.reversed().forEach { n -> notify(ctx, n) }
                rows.maxOfOrNull { it.optInt("id") }?.let { if (it > Store.lastNotif) Store.lastNotif = it }
                if (Store.lastNotif < 0) Store.lastNotif = 0
            } catch (e: ApiError) { if (e.code == 401) Session.loggedIn = false } catch (e: Exception) {}
            delay(30000)
        }
    }
    BackHandler(stack.isNotEmpty()) { stack = stack.dropLast(1) }

    val title = when (top?.k) {
        "order" -> "Order"; "client" -> "Client"; "tickets" -> "Tickets"; "ticket" -> "Ticket"; "notices" -> "Notices"
        "page" -> pageTitle(topA)
        else -> listOf("Home", "Orders", "Payments", "Clients", "More")[tab]
    }
    Column(Modifier.fillMaxSize().background(Color.White)) {
        Header(title, back = if (top != null) ({ stack = stack.dropLast(1) }) else null, bell = top?.k != "notices", onBell = { nav(Route("notices")) })
        Box(Modifier.weight(1f)) {
            when (top?.k) {
                "order" -> OrderDetail(topA)
                "client" -> ClientDetail(topA) { stack = stack.dropLast(1) }
                "tickets" -> TicketsScreen(nav, topA.toIntOrNull() ?: 0)
                "ticket" -> TicketThread(topA)
                "notices" -> NoticesScreen()
                "page" -> PageScreen(topA, topB, nav)
                else -> when (tab) {
                    0 -> HomeScreen(nav) { t, f -> tab = t; ordFilter = f }
                    1 -> OrdersScreen(nav, ordFilter) { ordFilter = it }
                    2 -> PaymentsScreen(nav)
                    3 -> ClientsScreen(nav)
                    else -> MoreScreen(nav, { Session.locked = Store.pin.isNotEmpty() }) {
                        sc.launch { try { withContext(Dispatchers.IO) { Api.call("logout") } } catch (e: Exception) {}; Store.clear(); Session.loggedIn = false }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Navy).navigationBarsPadding().height(60.dp)) {
            listOf("Home" to "⌂", "Orders" to "☰", "Payments" to "$", "Clients" to "☺", "More" to "⋯").forEachIndexed { i, (l, ic) ->
                Column(Modifier.weight(1f).fillMaxHeight().clickable { tab = i; stack = emptyList() }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    val on = i == tab && stack.isEmpty()
                    Text(ic, color = if (on) Color.White else Color(0xFF8FA0D8), fontSize = 20.sp)
                    Text(l, color = if (on) Color.White else Color(0xFF8FA0D8), fontSize = 11.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

fun pageTitle(p: String) = when (p) {
    "domains.php" -> "All domains"; "tlds.php" -> "Extensions and prices"; "registrars.php" -> "Registrar"
    "invoices.php" -> "Invoices"; "gateways.php" -> "Payment methods"; "referrals.php" -> "Referrals"
    "team.php" -> "Team"; "backup.php" -> "Backup"; "settings.php" -> "Settings"
    else -> p.removeSuffix(".php").replaceFirstChar { it.uppercase() }
}

fun notify(ctx: android.content.Context, n: JSONObject) {
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
    val pi = android.app.PendingIntent.getActivity(ctx, 0, android.content.Intent(ctx, MainActivity::class.java), android.app.PendingIntent.FLAG_IMMUTABLE)
    val nb = NotificationCompat.Builder(ctx, "rf").setSmallIcon(R.drawable.ic_notif).setContentTitle(n.optString("title"))
        .setContentText(n.optString("message")).setAutoCancel(true).setContentIntent(pi).build()
    ctx.getSystemService(NotificationManager::class.java).notify(n.optInt("id"), nb)
}
