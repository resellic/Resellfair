package com.resellfair.admin

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

const val SITE = "https://resellfair.com"
const val API = "$SITE/mobile-api.php"

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("rf", "Alerts", NotificationManager.IMPORTANCE_HIGH))
        }
    }
}

object Store {
    private lateinit var p: android.content.SharedPreferences
    fun init(c: Context) { p = c.getSharedPreferences("rf", Context.MODE_PRIVATE) }
    var token: String get() = p.getString("token", "") ?: ""; set(v) = p.edit().putString("token", v).apply()
    var payToken: String get() = p.getString("pay", "") ?: ""; set(v) = p.edit().putString("pay", v).apply()
    var pin: String get() = p.getString("pin", "") ?: ""; set(v) = p.edit().putString("pin", v).apply()
    var email: String get() = p.getString("email", "") ?: ""; set(v) = p.edit().putString("email", v).apply()
    var lastNotif: Int get() = p.getInt("ln", -1); set(v) = p.edit().putInt("ln", v).apply()
    val deviceId: String get() = p.getString("did", null) ?: UUID.randomUUID().toString().also { p.edit().putString("did", it).apply() }
    fun clear() { p.edit().remove("token").remove("pay").remove("pin").apply() }
}

class ApiError(msg: String, val code: Int = 0) : Exception(msg)

object Api {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Direct call to the site's own mobile-api.php. GET params go in the query, body (if any) is JSON. */
    fun call(a: String, query: Map<String, String> = emptyMap(), body: Map<String, Any?>? = null): JSONObject {
        val qs = (listOf("a=" + enc(a)) + query.map { enc(it.key) + "=" + enc(it.value) }).joinToString("&")
        val c = URL("$API?$qs").openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        if (Store.token.isNotEmpty()) c.setRequestProperty("X-App-Token", Store.token)
        c.setRequestProperty("Accept", "application/json")
        if (body != null) {
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject(body).toString().toByteArray()) }
        }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        val j = try { JSONObject(txt) } catch (e: Exception) { throw ApiError("Server error ($code)", code) }
        if (code == 401) { Store.token = ""; throw ApiError(j.optString("error", "Please log in again"), 401) }
        if (!j.optBoolean("ok", true)) throw ApiError(j.optString("error", "Failed"), code)
        return j
    }

    /** Silent SMS forwarding to the payment automation endpoint. */
    fun postSms(sender: String, body: String, at: String): Boolean = try {
        val c = URL("$SITE/sms-api.php").openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000; c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        val j = JSONObject().put("token", Store.payToken).put("sender", sender).put("body", body).put("received_at", at)
        c.outputStream.use { it.write(j.toString().toByteArray()) }
        c.responseCode in 200..299
    } catch (e: Exception) { false }
}

fun JSONArray.list(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
